package ghost;

import processing.core.PApplet;

public interface GameInterface {
    void tick();
    void draw(PApplet app);
}