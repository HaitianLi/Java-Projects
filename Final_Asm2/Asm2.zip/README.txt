The whole program not finished yet, some logics are missing as following

 	When in CHASE mode, Whim targets double the vector from Chaser to 2 grid spaces ahead of Waka .
	Pressing space activates/deactivates DEBUG mode
	Waka loses a life when he is hit by a Ghost
	Waka’s lives are shown at the bottom of the screen
	When Waka loses all of his lives, the Game Over Screen is shown
	After 10 seconds, result screens are cleared and the game restarts 
	When in FRIGHTENED mode, Waka can remove Ghosts by hitting them
	When Waka is hit by a Ghost, Waka and all Ghosts are reset to their starting positions 
	

The program set the first scatter mode to 50sec to show that scatter mode work.

Builder class is the gamemanager, all imgs loads to this class, and this class contain all other instance of other classes(waka, ghost, fruit, wall).


Inherit Map
father class is Gameobject class
	MoveObject class
		waka class
		ghost class
		    4 different ghost	
	MapObject class
		fruit class
		    super fruit class
		wall class