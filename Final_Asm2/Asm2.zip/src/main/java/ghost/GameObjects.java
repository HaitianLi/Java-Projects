package ghost;

import processing.core.PApplet;
import processing.core.PImage;

public abstract class GameObjects {
    private int x;
    private int y;
    private PImage sprite;

    public GameObjects(int x, int y, PImage sprite) {
        this.x = x;
        this.y = y;
        this.sprite = sprite;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public PImage getSprite() {
        return this.sprite;
    }

    public int getSpriteWidth() {
        return this.sprite.width;
    }

    public int getSpriteHeight() {
        return this.sprite.height;
    }

    public void setSprit(PImage img) {
        this.sprite = img;
    } 
    
    public void setX(int i) {
        this.x += i;
    }

    public void setY(int i) {
        this.y += i;
    }

    public void draw(PApplet app) {
        app.image(this.sprite, this.x, this.y);
    }

    public abstract void tick();

}