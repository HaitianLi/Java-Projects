package ghost;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import com.jogamp.opengl.Threading.Mode;

import java.io.File;
import java.util.ArrayList;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import processing.core.PImage;
import processing.core.PApplet;
import org.json.simple.JSONArray;



public class Builder {
 
    private Long lives;
    private Long speed;
    private Long FrightenedModeTime;
    private int WIDTH;
    private int HEIGHT;
    private int keyCode;
    private String MapFileName;
    private Waka waka;
    private Ghost ghost;
    private ArrayList<String> MapString;
    private ArrayList<Ghost> ghostList;
    private ArrayList<MapObjects> MapObjects;
    private ArrayList<MapObjects> Intersections;
    private ArrayList<Long> ModeTime = new ArrayList<Long>();
    private PImage FruitImg;
    private PImage GhostImg;
    private PImage GhostAmbusherImg;
    private PImage GhostChaserImg;
    private PImage GhostIgnorantImg;
    private PImage GhostWhimImg;
    public PImage GhostFrightImg;
    private PImage MapHorizontalImg;
    private PImage MapVerticalImg;
    private PImage MapUpLeftImg;
    private PImage MapUpRightImg;
    private PImage MapDownLeftImg;
    private PImage MapDownRightImg;
    public PImage wakaLeft;
    public PImage wakaRight;
    public PImage wakaUp;
    public PImage wakaDown;
    public PImage wakaClose;
    private Ambusher ambusher;
    private Ignorant ignorant;
    private Chaser chaser;
    private Whim whim;
    

    public Builder(int WIDTH, int HEIGHT) {
        this.WIDTH = WIDTH;
        this.HEIGHT = HEIGHT;
        MapString = new ArrayList<String>();
        ghostList = new ArrayList<Ghost>();
        MapObjects = new ArrayList<MapObjects>();
        Intersections = new ArrayList<MapObjects>();
        

    }

    public void setFruitImg(PImage i) {
        this.FruitImg = i;
    }

    public void setGhostImg(PImage i) {
        this.GhostImg = i;
    }

    public void setMapHorizontalImg(PImage i) {
        this.MapHorizontalImg = i;
    }

    public void setMapVerticalImg(PImage i) {
        this.MapVerticalImg = i;
    }

    public void setMapUpleftImg(PImage i) {
        this.MapUpLeftImg = i;
    }

    public void setMapUprightImg(PImage i) {
        this.MapUpRightImg = i;
    }

    public void setMapDownleftImg(PImage i) {
        this.MapDownLeftImg = i;
    }

    public void setMapDownrightImg(PImage i) {
        this.MapDownRightImg = i;
    }

    public void setWakaLeftImg(PImage i) {
        this.wakaLeft = i;
    }

    public void setWakaRightImg(PImage i) {
        this.wakaRight = i;
    }

    public void setWakaUpImg(PImage i) {
        this.wakaUp = i;
    }

    public void setWakaDownImg(PImage i) {
        this.wakaDown = i;
    }

    public void setWakaCloseImg(PImage i) {
        this.wakaClose = i;
    }


    public void setGhostWhimImg(PImage i) {
        this.GhostWhimImg = i;
    }

    public void setGhostAmbusherImg(PImage i) {
        this.GhostAmbusherImg = i;
    }

    public void setGhostChaserImg(PImage i) {
        this.GhostChaserImg = i;
    }

    public void setGhostIgnorantImg(PImage i) {
        this.GhostIgnorantImg = i;
    }
    public void setWakaImg() {
        waka.setWakaCloseImg(this.wakaClose);
        waka.setWakaDownImg(this.wakaDown);
        waka.setWakaLeftImg(this.wakaLeft);
        waka.setWakaRightImg(this.wakaRight);
        waka.setWakaUpImg(this.wakaUp);
    }
    
    public void setUp() {
        readJson();
        readMap();
        this.buildWaka();
        this.setMapObjects();
        this.setIntersections();
        this.setGhostList();
        this.setWakaImg();
        System.out.println(this.MapObjects.size());
    }



    //draw part start

    public void draw(PApplet app) {
        this.drawMap(app);
        this.drawGost(app);
        this.drawWaka(app);
    }

    public void drawWaka(PApplet app) {
        waka.draw(app);
    }

    public void drawGost(PApplet app) {
        //check null
        ambusher.draw(app);
        ignorant.draw(app);
        chaser.draw(app);
        whim.draw(app);
    }

    public void drawMap(PApplet app) {
        for (MapObjects m : MapObjects) {
            if (m.getSprite() != null) {
                m.draw(app);
            }
        }
    }
    //draw part end

    //tick part start
    public void wakaTick(PApplet app) {
        //check null
        this.waka.tick();
        this.ambusher.tick();
        this.ignorant.tick();
        this.chaser.tick();
        this.whim.tick();

        for (MapObjects f : MapObjects) {
            if (f.getClass() == Fruit.class) {
                f = (Fruit)f;
                f.tick();
            }

            if (f.getClass() == SuperFruit.class) {
                f = (SuperFruit)f;
                f.tick();
            }
        }

        //ghost.tick();
        //ghost.run(app);
    }
    //tick part end

    public void getKeyValue(int keycode) {
        this.keyCode = keycode;
        if (keyCode == 37) {
            waka.sendDirect(-1, 0);
        } else if (keyCode == 39) {
            waka.sendDirect(1, 0);
        } else if (keyCode == 38) {
            waka.sendDirect(0, -1);
        } else if (keyCode == 40) {
            waka.sendDirect(0, 1);
        }
    }

    public void setGhostList() {

        //could replace by a function which return (x,y)
        for (int i = 0; i < this.HEIGHT; i += 16) {
            String Map_row = this.MapString.get(i / 16);
            for (int j = 0; j< this.WIDTH; j += 16) {
                char temp_char = Map_row.charAt(j / 16);
                if (temp_char == 'a') {
                    this.ambusher = (new Ambusher(j, i, this.GhostAmbusherImg, this.MapObjects, this.speed.intValue(), waka, this.Intersections, this.ModeTime, this.FrightenedModeTime, this.GhostFrightImg));
                } else if (temp_char == 'i') {
                    this.ignorant = (new Ignorant(j, i, this.GhostIgnorantImg, this.MapObjects, this.speed.intValue(), waka, this.Intersections, this.ModeTime, this.FrightenedModeTime, this.GhostFrightImg));
                    
                } else if (temp_char == 'c') {
                    this.chaser = (new Chaser(j, i, this.GhostChaserImg, this.MapObjects, this.speed.intValue(), waka, this.Intersections, this.ModeTime, this.FrightenedModeTime, this.GhostFrightImg));
                } else if (temp_char == 'w') {
                    this.whim = (new Whim(j, i, this.GhostWhimImg, this.MapObjects, this.speed.intValue(), waka, this.Intersections, this.ModeTime, this.FrightenedModeTime, this.GhostFrightImg, this.chaser));

                }
            }
        }
    }

    public void setIntersections() {
        for (MapObjects m : this.MapObjects) {
            if (m.getReachable()) {
                if (waka.targetBlock(m.getX() + 16, m.getY()) || waka.targetBlock(m.getX() - 16, m.getY())) {
                    if (waka.targetBlock(m.getX(), m.getY() + 16) || waka.targetBlock(m.getX(), m.getY() - 16)) {
                        Intersections.add(m);
                    }
                }
            }
        }
    }

    public void buildWaka() {

        //could replace by a function which return (x,y)
        for (int i = 0; i < this.HEIGHT; i += 16) {
            String Map_row = this.MapString.get(i / 16);
            for (int j = 0; j< this.WIDTH; j += 16) {
                char temp_char = Map_row.charAt(j / 16);
                if (temp_char == 'p') {
                    this.waka = new Waka(j, i, wakaLeft, MapObjects, speed.intValue());
                }
            }
        }
    }

    public void setMapObjects() {
        for (int i = 0; i < this.HEIGHT; i += 16) {
            String Map_row = this.MapString.get(i / 16);
            for (int j = 0; j< this.WIDTH; j += 16) {
                char temp_char = Map_row.charAt(j / 16);
            
                if (temp_char == '1') {
                    this.MapObjects.add(new Wall(j, i, this.MapHorizontalImg, false));
                } else if (temp_char == '2') {
                    this.MapObjects.add( new Wall(j,i,this.MapVerticalImg, false));
                } else if (temp_char == '3') {
                    this.MapObjects.add(new Wall(j,i,this.MapUpLeftImg,false));
                } else if (temp_char == '4') {
                    this.MapObjects.add(new Wall(j,i,this.MapUpRightImg,false));
                } else if (temp_char == '5') {
                    this.MapObjects.add(new Wall(j,i,this.MapDownLeftImg,false));
                } else if (temp_char == '6') {
                    this.MapObjects.add(new Wall(j,i,this.MapDownRightImg,false));
                } else if (temp_char == '7') {
                    this.MapObjects.add(new Fruit(j, i, this.FruitImg, true, this.waka));
                } else if (temp_char == '8') {
                    this.MapObjects.add(new SuperFruit(j, i, this.FruitImg, true, this.waka));
                } else if (temp_char != '0') {
                    this.MapObjects.add(new MapObjects(j, i, null, true));
                }
            }
        }
    }

    public void readJson() {
        
        JSONParser jsonparse = new JSONParser();
        try {
            FileReader reader = new FileReader("config.json");
            Object obj = jsonparse.parse(reader);
            JSONObject empjsonobj = (JSONObject)obj;
            //System.out.println((String)empjsonobj.get("map"));
            this.MapFileName = (String)empjsonobj.get("map");
            //System.out.println(MapFileName);
            this.lives = (Long)empjsonobj.get("lives");

            this.speed = (Long)empjsonobj.get("speed");

            this.FrightenedModeTime = (Long)empjsonobj.get("frightenedLength");

            JSONArray array1 = (JSONArray)empjsonobj.get("modeLengths");
            for (Object i : array1) {
                this.ModeTime.add((Long)i);
            }
            
        } catch(Exception e) {
            System.out.println("No such json file.");
        }
        
    }

    public void readMap() {
        
        ArrayList<String> result = new ArrayList<String>();
        try {
            File fname = new File(this.MapFileName);
            Scanner scan = new Scanner(fname);
            while(scan.hasNextLine()){
                result.add(scan.nextLine());
            }
            scan.close();
        } catch(FileNotFoundException e) {
            System.out.println("map File not exist.");
        }


        this.MapString = result;
    }

    
    // public ArrayList<int[]> locateXY(char ch) {
    //     ArrayList<int[]> temp = new ArrayList<int[]>();

        
    //     for (int i = 0; i < this.HEIGHT; i += 16) {
    //         String Map_row = this.MapString.get(i / 16);

    //         for (int j = 0; j< this.WIDTH; j += 16) {
    //             int [] result = new int[2];
    //             char temp_char = Map_row.charAt(j / 16);
    //             if (temp_char == ch) {
    //                 result[0] = j;
    //                 result[1] = i;
    //                 temp.add(result);
    //             }
    //         }
    //     }
    //     return temp;
    // }


    // //  7,
    //     20,
    //     7,
    //     20,
    //     5,
    //     20,
    //     5,
    //     1000
}