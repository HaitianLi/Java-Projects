package ghost;
import java.util.ArrayList;
import processing.core.PApplet;
import processing.core.PImage;


public class Ambusher extends Ghost {
    private Waka waka;
    private boolean touchInter;
    public Ambusher(int x, int y, PImage sprite, ArrayList<MapObjects> MapObjects, int speed, Waka waka, ArrayList<MapObjects> Intersections,ArrayList<Long> ModeTime, Long FrightenedModeTime, PImage GhostFrightImg ) {
        super(x, y, sprite, MapObjects, speed, waka, Intersections, ModeTime, FrightenedModeTime, GhostFrightImg);
        this.waka = waka;

    }


    // redo the logic, the pink one will stack
    public void tick() {
        checkLocation();
        radar();
        checkNode();
        PassIntersection(448,0);
        move();
        ModeChange();
        //checkFrightenedMode();

        if (!getFrightenedMode()) {
            setTimer();
        }

    }

    public void checkNode() {
        for (MapObjects m : getIntersections()) {
            if (this.getX() == m.getX() && this.getY() == m.getY()) {
                this.touchInter = true;
                break;
            }
        }
    }
    public void DebugMode(PApplet app) {
        app.line(this.getX() + 8, this.getY() + 8, waka.getX() + 8, waka.getY() + 8);
        app.stroke(200);
    }
    public void PassIntersection(int x, int y) {
        if (touchInter) {
            if (getDx() == -1) {
                setRightmoveable(false);
            } else if (getDx() == 1) {
                setLeftmoveable(false);
            } else if (getDy() == -1) {
                setDownmoveable(false);
            } else if (getDy() == 1) {
                setUpmoveable(false);
            }
            if (!getFrightenedMode()) {
                if (getScaterMode()) {
                    this.MakeATurn(x,y);
                } else if (getChaseMode()) {
                    //System.out.printf("%d %d %d %d\n", waka.getX(), waka.getX() + (waka.getDx()*(16*4)), waka.getY(), waka.getY() + (waka.getDy()*(16*4)));
                    // this.targetX = waka.getX() + (waka.getDx()*(16*4));
                    // this.targetY = waka.getY() + (waka.getDy()*(16*4));
                    // if (targetX < 0) {
                    //     targetX = 0;
                    // }
                    // if (targetY < 0) {
                    //     targetY = 0;
                    // }
                    setTargetX(waka.getX() + (waka.getDx()*(16*4)));
                    setTargetY(waka.getY() + (waka.getDy()*(16*4)));
                    
                    this.MakeATurn(getTargetX(), getTargetY());
                }
            } else {
                moveRandom();
            }
            this.touchInter = false;
        }
        // for(MapObjects m: getIntersections()) {
        //     if (this.getX() == m.getX() && this.getY() == m.getY()){
        //         //ghost could not make a turn;
        //         //System.out.printf("%b %b %b %b\n",getLeftMoveable(), getRightMoveable(), getUpMoveable(),getDownMoveable());
                
        //         break;
        //         //this.setPriviousLocation(m.getX(), m.getY());
        //     }
        // }
    }
}